﻿using System.Windows.Forms;

namespace DummyClient
{
    // 컨텐츠 처리
    internal abstract class ContentsProcess
    {
        //Todo : 공통 처리를 아래와 같이 기술합니다
        /*static public void exitPacket(PacketInterface packet)
        {
            Program.programState_.close();
            Application.Exit();
        }
        */
    }
}