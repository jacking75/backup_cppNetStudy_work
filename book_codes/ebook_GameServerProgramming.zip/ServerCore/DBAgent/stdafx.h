// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

// TODO: reference additional headers your program requires here
#include "ServerLibrary.h"

// ��������..
#include "./Query/QI_DB_REQ_ID_PW.h"
#include "./Query/QI_DB_REQ_LOAD_DATA.h"