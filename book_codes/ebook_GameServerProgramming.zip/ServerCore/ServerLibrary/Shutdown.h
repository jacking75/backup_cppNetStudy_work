#pragma once
#include "stdafx.h"
//-------------------------------------------------------------------//
extern bool _shutdown;
extern void shutdownServer();
