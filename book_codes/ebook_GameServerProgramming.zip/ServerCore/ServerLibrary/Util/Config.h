#pragma once
#include "stdafx.h"

extern bool loadConfig(xml_t *config);