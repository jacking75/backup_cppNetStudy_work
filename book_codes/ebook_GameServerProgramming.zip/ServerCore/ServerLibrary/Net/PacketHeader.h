#pragma once
#include "../stdafx.h"

enum EPacket {
    /*0*/    E_C_REQ_ID_PW,
    /*1*/    E_S_REQ_ID_ID_PW,
    /*2*/    E_C_NOTIFY_HEARTBEET,
    /*3*/    E_C_REQ_CHATTING,
    /*4*/    E_S_REQ_CHATTING,
};
