﻿# Shared Components

This folder contains the some UWP components that will be used for other XAML Islands samples. You can find here:

1. A __managed WinRT Component__ in C# with UWP XAML. 
2. A __native WinRT Component__ in C++/WinRT that uses the UWP SwapChainPanel control to render Direct2D content.
3. An __UWP app__ for testing these components in their "natural" enviorment.


