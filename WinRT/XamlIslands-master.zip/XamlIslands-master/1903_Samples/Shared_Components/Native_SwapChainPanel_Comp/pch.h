﻿#pragma once

#include <collection.h>
#include <ppltasks.h>
#include "DirectXHelper.h"
#include <dxgi1_4.h>
#include <d2d1_3.h>
#include <d3d11_3.h>
#include <wrl.h>
#include <wrl/client.h>

#include "windows.ui.xaml.media.dxinterop.h"

