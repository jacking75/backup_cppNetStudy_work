#pragma once

#include "resource.h"

#define ButtonMargin   10
#define ButtonWidth   100
#define ButtonHeight   50
#define XamlIslandMargin ButtonMargin+ButtonHeight
#define InitialHeight 1000
#define InitialWidth  900

INT_PTR CALLBACK About(HWND, UINT, WPARAM, LPARAM);

