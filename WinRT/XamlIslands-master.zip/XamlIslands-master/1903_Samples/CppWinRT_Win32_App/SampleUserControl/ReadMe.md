# WinRT Conmponent with UWP XAML User Controls

This project is a UWP WinRT Component that contains a UWP XAML User Controls.

